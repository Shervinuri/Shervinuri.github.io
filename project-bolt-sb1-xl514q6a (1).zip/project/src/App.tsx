import React, { useState, useCallback } from 'react';
import { Users, User, CreditCard, Coins } from 'lucide-react';

interface PricingItem {
  title: string;
  single: { toman: string; tron: string };
  dual: { toman: string; tron: string };
}

interface ToggleProps {
  isActive: boolean;
  onToggle: () => void;
  leftLabel: string;
  rightLabel: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  className?: string;
}

const Toggle: React.FC<ToggleProps> = ({
  isActive,
  onToggle,
  leftLabel,
  rightLabel,
  leftIcon,
  rightIcon,
  className = ""
}) => {
  return (
    <div 
      className={`relative w-full h-16 bg-gradient-to-r from-slate-900/90 to-slate-800/90 rounded-full flex items-center cursor-pointer overflow-hidden p-2 border border-slate-600/40 shadow-2xl backdrop-blur-sm transition-all duration-300 hover:shadow-blue-500/20 hover:border-slate-500/60 ${className}`}
      onClick={onToggle}
      style={{
        boxShadow: '0 8px 32px rgba(0, 0, 0, 0.4), inset 0 1px 2px rgba(255, 255, 255, 0.1), 0 0 20px rgba(59, 130, 246, 0.1)'
      }}
    >
      {/* Background Labels */}
      <div className="w-1/2 flex justify-center items-center text-slate-300 text-base font-medium transition-colors duration-300">
        <span className="flex items-center gap-2">
          {rightIcon}
          {rightLabel}
        </span>
      </div>
      <div className="w-1/2 flex justify-center items-center text-slate-300 text-base font-medium transition-colors duration-300">
        <span className="flex items-center gap-2">
          {leftIcon}
          {leftLabel}
        </span>
      </div>
      
      {/* Animated Handle */}
      <div 
        className={`absolute top-2 w-[calc(50%-8px)] h-[calc(100%-16px)] bg-gradient-to-r from-blue-500 to-blue-600 rounded-full shadow-2xl transform transition-all duration-500 ease-out ${
          isActive ? 'right-2 bg-gradient-to-r from-purple-500 to-purple-600' : 'right-[calc(50%+2px)]'
        }`}
        style={{
          boxShadow: isActive 
            ? '0 12px 40px rgba(147, 51, 234, 0.5), 0 6px 20px rgba(0, 0, 0, 0.4), inset 0 2px 4px rgba(255, 255, 255, 0.2), 0 0 30px rgba(147, 51, 234, 0.3)'
            : '0 12px 40px rgba(59, 130, 246, 0.5), 0 6px 20px rgba(0, 0, 0, 0.4), inset 0 2px 4px rgba(255, 255, 255, 0.2), 0 0 30px rgba(59, 130, 246, 0.3)'
        }}
      >
        <div className="w-full h-full flex justify-center items-center text-white font-semibold relative">
          <div className={`transition-all duration-300 ${isActive ? 'opacity-0 scale-75' : 'opacity-100 scale-100'}`}>
            <span className="flex items-center gap-1 text-sm">
              {leftIcon}
              {leftLabel}
            </span>
          </div>
          <div className={`absolute inset-0 flex justify-center items-center transition-all duration-300 ${isActive ? 'opacity-100 scale-100' : 'opacity-0 scale-75'}`}>
            <span className="flex items-center gap-1 text-sm">
              {rightIcon}
              {rightLabel}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

const PriceToggle: React.FC<{ prices: { toman: string; tron: string } }> = ({ prices }) => {
  const [showTron, setShowTron] = useState(false);
  const isAvailable = prices.toman !== '—';

  if (!isAvailable) {
    return (
      <div className="h-14 flex justify-center items-center text-slate-400 font-semibold bg-gradient-to-r from-slate-800/50 to-slate-700/50 rounded-full border border-slate-700/50 shadow-inner">
        ناموجود
      </div>
    );
  }

  return (
    <div 
      className={`relative w-full h-14 bg-gradient-to-r from-slate-900/90 to-slate-800/90 rounded-full flex items-center cursor-pointer overflow-hidden p-1.5 border border-slate-600/40 shadow-2xl backdrop-blur-sm transition-all duration-300 hover:shadow-purple-500/20 hover:border-slate-500/60`}
      onClick={() => setShowTron(!showTron)}
      style={{
        boxShadow: '0 6px 24px rgba(0, 0, 0, 0.4), inset 0 1px 2px rgba(255, 255, 255, 0.1), 0 0 15px rgba(59, 130, 246, 0.08)'
      }}
    >
      {/* Background Labels - واحدها */}
      <div className="w-1/2 flex justify-center items-center text-slate-300 text-sm font-medium">
        TRX
      </div>
      <div className="w-1/2 flex justify-center items-center text-slate-300 text-sm font-medium">
        تومان
      </div>
      
      {/* Animated Handle */}
      <div 
        className={`absolute top-[6px] w-[calc(50%-6px)] h-[calc(100%-12px)] bg-gradient-to-r from-gray-600 to-gray-700 rounded-full shadow-2xl transform transition-all duration-500 ease-out ${
          showTron ? 'right-[6px] bg-gradient-to-r from-orange-500 to-orange-600' : 'right-[calc(50%)]'
        }`}
        style={{
          boxShadow: showTron 
            ? '0 8px 32px rgba(249, 115, 22, 0.4), 0 4px 16px rgba(0, 0, 0, 0.4), inset 0 2px 4px rgba(255, 255, 255, 0.2), 0 0 20px rgba(249, 115, 22, 0.3)'
            : '0 8px 32px rgba(75, 85, 99, 0.4), 0 4px 16px rgba(0, 0, 0, 0.4), inset 0 2px 4px rgba(255, 255, 255, 0.2)'
        }}
      >
        <div className="w-full h-full flex justify-center items-center text-white font-bold relative">
          {/* قیمت تومان */}
          <div className={`transition-all duration-300 ${showTron ? 'opacity-0 scale-75' : 'opacity-100 scale-100'}`}>
            <span className="text-sm">{prices.toman}</span>
          </div>
          {/* قیمت TRX */}
          <div className={`absolute inset-0 flex justify-center items-center transition-all duration-300 ${showTron ? 'opacity-100 scale-100' : 'opacity-0 scale-75'}`}>
            <span className="text-sm">{prices.tron}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

const PricingCard: React.FC<{ item: PricingItem; userType: 'single' | 'dual' }> = ({ item, userType }) => {
  const prices = item[userType];
  
  return (
    <div className="pricing-item group">
      <div 
        className="bg-gradient-to-br from-slate-800/70 to-slate-900/70 rounded-2xl p-6 border border-slate-600/40 backdrop-blur-sm transition-all duration-300 hover:scale-[1.02] hover:bg-gradient-to-br hover:from-slate-700/70 hover:to-slate-800/70"
        style={{
          boxShadow: '0 10px 40px rgba(0, 0, 0, 0.3), inset 0 1px 2px rgba(255, 255, 255, 0.1), 0 0 20px rgba(59, 130, 246, 0.05)'
        }}
      >
        <h3 className="text-lg font-medium text-slate-200 mb-4 text-center group-hover:text-white transition-colors duration-300">
          {item.title}
        </h3>
        <PriceToggle prices={prices} />
      </div>
    </div>
  );
};

function App() {
  const [userType, setUserType] = useState<'single' | 'dual'>('single');

  const pricingData: PricingItem[] = [
    { title: "۱ ماهه - ۳۰ گیگ", single: { toman: "140,000", tron: "6" }, dual: { toman: "150,000", tron: "6" } },
    { title: "۱ ماهه - ۴۵ گیگ", single: { toman: "160,000", tron: "7" }, dual: { toman: "170,000", tron: "7" } },
    { title: "۱ ماهه - نامحدود", single: { toman: "220,000", tron: "9" }, dual: { toman: "440,000", tron: "18" } },
    { title: "۲ ماهه - نامحدود", single: { toman: "440,000", tron: "18" }, dual: { toman: "—", tron: "—" } },
    { title: "۱۲ ماهه - نامحدود", single: { toman: "2,500,000", tron: "102" }, dual: { toman: "—", tron: "—" } }
  ];

  const handleUserTypeToggle = useCallback(() => {
    setUserType(prev => prev === 'single' ? 'dual' : 'single');
  }, []);

  return (
    <div 
      className="min-h-screen flex justify-center items-center p-4"
      style={{
        background: 'radial-gradient(ellipse at center, rgba(59, 130, 246, 0.15) 0%, rgba(15, 23, 42, 0.9) 50%, rgba(15, 23, 42, 1) 100%), linear-gradient(135deg, #0f172a 0%, #1e293b 100%)'
      }}
    >
      <div className="w-full max-w-sm mx-auto">
        {/* Main Card */}
        <div 
          className="bg-gradient-to-br from-slate-800/90 to-slate-900/90 rounded-3xl shadow-2xl p-8 text-white border border-slate-600/40 backdrop-blur-xl relative overflow-hidden"
          style={{
            boxShadow: '0 32px 64px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(255, 255, 255, 0.05), inset 0 2px 4px rgba(255, 255, 255, 0.1), 0 0 40px rgba(59, 130, 246, 0.1)'
          }}
        >
          {/* Animated Background Elements */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-0 left-0 w-40 h-40 bg-blue-500 rounded-full blur-3xl animate-pulse"></div>
            <div className="absolute bottom-0 right-0 w-32 h-32 bg-purple-500 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
            <div className="absolute top-1/2 left-1/2 w-24 h-24 bg-cyan-500 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '2s' }}></div>
          </div>

          {/* Header */}
          <header className="text-center mb-10 relative z-10">
            <div 
              className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-3xl mb-6 shadow-2xl"
              style={{
                boxShadow: '0 16px 40px rgba(59, 130, 246, 0.4), 0 8px 20px rgba(0, 0, 0, 0.3), inset 0 2px 4px rgba(255, 255, 255, 0.2)'
              }}
            >
              <div className="text-3xl font-bold">S</div>
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent mb-2">
              Sky VPN
            </h1>
            <p className="text-slate-400 text-sm">پورتال قیمت‌گذاری حرفه‌ای</p>
          </header>

          {/* User Type Toggle */}
          <div className="mb-12 relative z-10">
            <div className="text-center mb-6">
              <span className="text-slate-300 text-sm font-medium bg-slate-800/50 px-4 py-2 rounded-full border border-slate-600/30">نوع کاربری</span>
            </div>
            <Toggle
              isActive={userType === 'dual'}
              onToggle={handleUserTypeToggle}
              leftLabel="تک کاربره"
              rightLabel="دو کاربره"
              leftIcon={<User size={18} />}
              rightIcon={<Users size={18} />}
            />
          </div>

          {/* Pricing List */}
          <div className="space-y-6 relative z-10">
            {pricingData.map((item, index) => (
              <div 
                key={index}
                className="animate-fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <PricingCard item={item} userType={userType} />
              </div>
            ))}
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes fade-in {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fade-in {
          animation: fade-in 0.6s ease-out forwards;
          opacity: 0;
        }
      `}</style>
    </div>
  );
}

export default App;