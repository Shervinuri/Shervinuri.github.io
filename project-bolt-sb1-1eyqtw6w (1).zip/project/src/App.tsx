import React, { useState, useEffect } from 'react';
import { ArrowRight } from 'lucide-react';

function App() {
  const [phoneClicked, setPhoneClicked] = useState(false);
  const [pulseAnimation, setPulseAnimation] = useState(true);

  useEffect(() => {
    // Improved rhythm: more natural pulsing every 4 seconds
    const interval = setInterval(() => {
      setPulseAnimation(false);
      setTimeout(() => setPulseAnimation(true), 200);
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  const handlePhoneClick = () => {
    setPhoneClicked(true);
    // Open the provided link
    setTimeout(() => {
      window.open('https://ce.yebekhe.workers.dev', '_blank');
    }, 800);
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `url('/src/assets/20250704_1910_صحنه کاری مدرن_remix_01jzb1dd1hentv1cjwqgf55spt copy.png')`
        }}
      >
        {/* Subtle dark overlay for better contrast */}
        <div className="absolute inset-0 bg-black/10"></div>
      </div>

      {/* Interactive phone overlay - repositioned further right and lower */}
      <div className="absolute inset-0">
        {/* Phone click area - moved further right and down */}
        <div 
          className="absolute cursor-pointer group transform rotate-[25deg]"
          style={{
            // Moved further right and down
            bottom: '15%', // Moved down from 20% to 15%
            right: '-6%', // Moved further right from -2% to -6%
            width: '28%', // Slightly increased width
            height: '30%', // Slightly increased height
            minWidth: '150px',
            minHeight: '170px',
            maxWidth: '260px',
            maxHeight: '260px'
          }}
          onClick={handlePhoneClick}
        >
          {/* Main glowing effect - softer fade from center */}
          <div 
            className={`absolute inset-0 bg-gradient-radial from-cyan-400/20 via-cyan-400/8 to-transparent rounded-3xl blur-lg transition-all duration-1000 ${
              pulseAnimation ? 'animate-pulse scale-110 opacity-80' : 'scale-100 opacity-40'
            } ${phoneClicked ? 'scale-150 opacity-30' : ''} group-hover:scale-125 group-hover:opacity-65`}
          ></div>
          
          {/* Secondary glow ring - gradual fade */}
          <div 
            className={`absolute inset-0 bg-gradient-radial from-emerald-400/15 via-emerald-400/6 to-transparent rounded-3xl blur-xl transition-all duration-1200 ${
              pulseAnimation ? 'animate-pulse scale-125 opacity-60' : 'scale-105 opacity-30'
            } ${phoneClicked ? 'scale-175 opacity-20' : ''} group-hover:scale-140 group-hover:opacity-50`}
          ></div>

          {/* Outer glow ring - very soft fade */}
          <div 
            className={`absolute inset-0 bg-gradient-radial from-blue-300/10 via-blue-300/4 to-transparent rounded-3xl blur-2xl transition-all duration-1500 ${
              pulseAnimation ? 'animate-pulse scale-150 opacity-40' : 'scale-130 opacity-20'
            } ${phoneClicked ? 'scale-200 opacity-12' : ''} group-hover:scale-160 group-hover:opacity-35`}
          ></div>

          {/* Extended glow to the right - soft gradient fade */}
          <div 
            className={`absolute inset-0 bg-gradient-to-r from-transparent via-cyan-300/6 via-cyan-300/3 to-transparent rounded-3xl blur-3xl transition-all duration-1800 ${
              pulseAnimation ? 'animate-pulse scale-170 opacity-35' : 'scale-140 opacity-18'
            } ${phoneClicked ? 'scale-220 opacity-8' : ''} group-hover:scale-190 group-hover:opacity-28`}
          ></div>

          {/* Ultra-wide right extension - very subtle fade */}
          <div 
            className={`absolute inset-0 bg-gradient-to-r from-transparent via-transparent via-blue-400/4 to-transparent rounded-3xl blur-[60px] transition-all duration-2000 ${
              pulseAnimation ? 'animate-pulse scale-200 opacity-25' : 'scale-160 opacity-12'
            } ${phoneClicked ? 'scale-250 opacity-6' : ''} group-hover:scale-220 group-hover:opacity-20`}
          ></div>

          {/* Invisible clickable area */}
          <div className="relative w-full h-full bg-transparent rounded-3xl transition-all duration-300">
            
            {/* Enhanced center ripple effect - multiple expanding rings */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              {/* Outer ripple ring - softer */}
              <div className={`absolute w-20 h-20 md:w-28 md:h-28 border border-cyan-400/20 rounded-full transition-all duration-2000 ${
                pulseAnimation ? 'animate-ping scale-150 opacity-40' : 'scale-100 opacity-15'
              } ${phoneClicked ? 'scale-200 opacity-60' : ''}`}></div>
              
              {/* Middle ripple ring - softer */}
              <div className={`absolute w-14 h-14 md:w-20 md:h-20 border border-emerald-400/25 rounded-full transition-all duration-1500 ${
                pulseAnimation ? 'animate-ping scale-125 opacity-50' : 'scale-100 opacity-18'
              } ${phoneClicked ? 'scale-175 opacity-65' : ''}`} style={{ animationDelay: '0.3s' }}></div>
              
              {/* Inner ripple ring - softer */}
              <div className={`absolute w-8 h-8 md:w-12 md:h-12 border border-blue-400/30 rounded-full transition-all duration-1000 ${
                pulseAnimation ? 'animate-ping scale-110 opacity-60' : 'scale-100 opacity-20'
              } ${phoneClicked ? 'scale-150 opacity-70' : ''}`} style={{ animationDelay: '0.6s' }}></div>
              
              {/* Center dot - dimmer and blinking */}
              <div className={`w-3 h-3 md:w-4 md:h-4 bg-gradient-to-br from-cyan-300/60 to-emerald-400/50 rounded-full shadow-sm shadow-cyan-400/30 transition-all duration-800 animate-pulse ${
                pulseAnimation ? 'scale-110 opacity-50' : 'scale-100 opacity-25'
              } ${phoneClicked ? 'scale-150 opacity-70' : ''} group-hover:scale-125 group-hover:opacity-60`}></div>
            </div>

            {/* Additional center glow effect - much softer */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className={`w-12 h-12 md:w-16 md:h-16 bg-gradient-radial from-cyan-400/12 via-cyan-400/4 to-transparent rounded-full blur-md transition-all duration-1200 ${
                pulseAnimation ? 'animate-pulse scale-120 opacity-40' : 'scale-100 opacity-20'
              } ${phoneClicked ? 'scale-180 opacity-50' : ''} group-hover:scale-140 group-hover:opacity-35`}></div>
            </div>

            {/* Refined sparkle effects - dimmer neon electronic colors */}
            <div className="absolute -top-2 -right-2 w-2 h-2 bg-cyan-300/30 rounded-full opacity-25 animate-pulse blur-sm shadow-sm shadow-cyan-300/20" style={{ animationDelay: '0.8s', animationDuration: '3s' }}></div>
            <div className="absolute -bottom-2 -left-2 w-2 h-2 bg-emerald-400/25 rounded-full opacity-20 animate-pulse blur-sm shadow-sm shadow-emerald-400/15" style={{ animationDelay: '1.6s', animationDuration: '3.5s' }}></div>
            <div className="absolute top-1/4 -right-3 w-1 h-1 bg-blue-400/35 rounded-full opacity-30 animate-pulse blur-sm shadow-sm shadow-blue-400/20" style={{ animationDelay: '2.4s', animationDuration: '4s' }}></div>
            <div className="absolute bottom-1/4 -left-3 w-1 h-1 bg-green-500/30 rounded-full opacity-25 animate-pulse blur-sm shadow-sm shadow-green-500/15" style={{ animationDelay: '3.2s', animationDuration: '3.8s' }}></div>
            <div className="absolute top-3/4 right-2 w-1 h-1 bg-teal-300/35 rounded-full opacity-20 animate-pulse blur-sm shadow-sm shadow-teal-300/15" style={{ animationDelay: '4s', animationDuration: '4.2s' }}></div>
            
            {/* Additional refined sparkles - very subtle */}
            <div className="absolute top-1/2 -right-4 w-1 h-1 bg-cyan-200/40 rounded-full opacity-30 animate-pulse blur-sm" style={{ animationDelay: '1.2s', animationDuration: '3.6s' }}></div>
            <div className="absolute top-1/3 right-1/4 w-1 h-1 bg-emerald-400/35 rounded-full opacity-25 animate-pulse blur-sm" style={{ animationDelay: '2.8s', animationDuration: '4.4s' }}></div>
            <div className="absolute bottom-1/3 right-1/3 w-1 h-1 bg-blue-200/40 rounded-full opacity-20 animate-pulse blur-sm" style={{ animationDelay: '3.6s', animationDuration: '3.2s' }}></div>

            {/* Breathing effect overlay - very subtle */}
            <div className={`absolute inset-0 bg-gradient-radial from-cyan-400/0 to-transparent rounded-3xl transition-all duration-3000 ${
              pulseAnimation ? 'from-cyan-400/4 scale-105' : 'scale-100'
            }`}></div>
          </div>

          {/* Enhanced hover glow - subtle */}
          <div className="absolute inset-0 bg-gradient-radial from-cyan-400/0 to-transparent group-hover:from-cyan-400/8 rounded-3xl transition-all duration-700 group-hover:scale-105"></div>
          
          {/* Magnetic attraction effect on hover - very subtle */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent to-blue-200/3 rounded-3xl opacity-0 group-hover:opacity-100 transition-all duration-900 group-hover:scale-110"></div>
        </div>
      </div>

      {/* Success animation overlay */}
      {phoneClicked && (
        <div className="fixed inset-0 bg-cyan-600/15 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-6 md:p-8 shadow-2xl transform animate-bounce max-w-sm mx-4">
            <div className="text-center">
              <div className="w-12 h-12 md:w-16 md:h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4 animate-spin">
                <ArrowRight className="w-6 h-6 md:w-8 md:h-8 text-white" />
              </div>
              <h3 className="text-lg md:text-xl font-bold text-gray-900 mb-2">در حال انتقال...</h3>
              <p className="text-gray-600 text-sm md:text-base">لطفاً صبر کنید</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;